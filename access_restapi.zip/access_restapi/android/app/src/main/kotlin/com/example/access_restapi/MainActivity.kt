package com.example.access_restapi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
